from django.db import models
from django.contrib import admin
# Create your models here.
class BlogsPost(models.Model):
    title = models.CharField(max_length = 150)
    number=models.IntegerField()
    body = models.TextField()
    timestamp = models.DateTimeField()
class TechPost(models.Model):
	title = models.CharField(max_length = 150)
	summary = models.TextField()
	number = models.IntegerField()
	timestamp = models.DateTimeField()
class BlogPostAdmin(admin.ModelAdmin):
    list_display = ('title','timestamp')
class TechPostAdmin(admin.ModelAdmin):
	list_display = ('title','timestamp')

admin.site.register(BlogsPost,BlogPostAdmin)
admin.site.register(TechPost,TechPostAdmin)
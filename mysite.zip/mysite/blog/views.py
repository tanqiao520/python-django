#coding=utf-8
from django.shortcuts import render
from blog.models import BlogsPost,TechPost
from django.shortcuts import render_to_response
# Create your views here.
def index(request):
    blogs = BlogsPost.objects.all()
    techblogs = TechPost.objects.all()
    blog_list=[]
    for row in blogs:
    	d = {"title":row.title,"number":row.number,"body":row.body,"timestamp":row.timestamp}
    	blog_list.append(d)
    blog_list.reverse()
    tech_blog_list=[]
    for row in techblogs:
    	d = {"title":row.title,"number":row.number,"summary":row.summary,"timestamp":row.timestamp}
    	tech_blog_list.append(d)
    tech_blog_list.reverse()

    return render_to_response('index.html',{'blog_list':blog_list,'tech_blog_list':tech_blog_list})